﻿using System;
using Xunit;

namespace MindboxLib
{
    public class Tests
    {
        [Fact]
        public void isZeroArea()
        {
            Triangle tr = new Triangle();
            Assert.Equal(0, tr.getArea());
        }
    }
}

﻿namespace MindboxLib
{
    interface IFigure
    {
        public double getPerimeter();
        public double getArea();
    }
}
